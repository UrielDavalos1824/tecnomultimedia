let estadoJuego = "menu"; // menu, tutorial, juego, victoria, derrota

let jugador;
let zombies = [];
let civiles = [];
let balas = [];

let tiempoSpawnZombie = 0;
let tiempoSpawnCivil = 0;

let zombiesEliminados = 0;
let tiempoPowerUp = 0;
let tiempoTutorial = 240;

let imagenInicio;
let sonidoZombie;


//Recursos

function preload() {
  imagenInicio = loadImage("pantallainicio.jpg");
  sonidoZombie = loadSound("zombie.mp3");
}


// Jugador
class Jugador {
  constructor() {
    this.x = 580;
    this.y = height / 2;
    this.tamano = 40;
    this.tamanoNormal = 40;
    this.tamanoGrande = 60;
    this.poderActivo = false;
  }

  actualizar() {
    if (keyIsDown(UP_ARROW)) this.y -= 4;
    if (keyIsDown(DOWN_ARROW)) this.y += 4;

    this.y = constrain(this.y, 0, height);
  }

  dibujar() {
    fill(0, 100, 255);
    rectMode(CENTER);
    rect(this.x, this.y, this.tamano, this.tamano);
  }

  disparar() {
    balas.push(new Bala(this.x, this.y, this.poderActivo));
  }

  activarPoder() {
    this.poderActivo = true;
    this.tamano = this.tamanoGrande;
    tiempoPowerUp = 120;
  }

  desactivarPoder() {
    this.poderActivo = false;
    this.tamano = this.tamanoNormal;
  }
}

// Zombies
class Zombie {
  constructor() {
    this.x = 0;
    this.y = random(20, height - 20);
    this.radio = 20;
    this.velocidad = 0.8;
    this.hp = 2;
  }

  actualizar() { this.x += this.velocidad; }

  dibujar() {
    fill(0, 200, 0);
    ellipse(this.x, this.y, this.radio * 2);
  }
}

// Civiles
class Civil {
  constructor() {
    this.x = 0;
    this.y = random(20, height - 20);
    this.radio = 12;
    this.velocidad = 1.7;
  }

  actualizar() { this.x += this.velocidad; }

  dibujar() {
    fill(0, 150, 255);
    ellipse(this.x, this.y, this.radio * 2);
  }
}

// Municion
class Bala {
  constructor(x, y, especial) {
    this.x = x;
    this.y = y;
    this.velocidad = 6;
    this.especial = especial;
    this.tamano = especial ? 20 : 10;
  }

  actualizar() { this.x -= this.velocidad; }

  dibujar() {
    if (this.especial) {
      fill(255, 0, 0);
      rectMode(CENTER);
      rect(this.x, this.y, this.tamano, this.tamano);
    } else {
      fill(255, 255, 0);
      triangle(
        this.x, this.y - 5,
        this.x, this.y + 5,
        this.x - this.tamano, this.y
      );
    }
  }
}


//SetUp
function setup() {
  createCanvas(640, 480);
  jugador = new Jugador();
}

//dRaw
function draw() {
  background(30);

  if (estadoJuego === "menu") dibujarMenu();
  else if (estadoJuego === "tutorial") dibujarTutorial();
  else if (estadoJuego === "juego") dibujarJuego();
  else if (estadoJuego === "victoria") dibujarVictoria();
  else if (estadoJuego === "derrota") dibujarDerrota();
}

// Menu
function dibujarMenu() {
  image(imagenInicio, 0, 0, width, height);

  fill(0, 120, 0);
  stroke(10, 200, 10);
  strokeWeight(3);

  textAlign(CENTER);
  textSize(36);
  text("Defensor del Apocalipsis", width / 2, 120);

  textSize(20);
  text("Presiona ENTER para empezar", width / 2, 350);

  noStroke();
}

//Tutorial
function dibujarTutorial() {
  tiempoTutorial--;

  fill(255);
  textAlign(CENTER);
  textSize(24);
  text("Instrucciones", width / 2, 80);

  textSize(16);
  text("Muévete con ↑ y ↓", width / 2, 150);
  text("Dispara con ESPACIO", width / 2, 180);
  text("Salva a los civiles", width / 2, 210);

  // Muestra civil
  fill(0, 150, 255);
  ellipse(width / 2 + 120, 205, 24);

  if (tiempoTutorial <= 0) {
    estadoJuego = "juego";
  }
}


//Gameplay
function dibujarJuego() {

  jugador.actualizar();
  jugador.dibujar();

  //poder especial (powerup)
  if (jugador.poderActivo) {
    tiempoPowerUp--;
    if (tiempoPowerUp <= 0) jugador.desactivarPoder();
  }

  //zombie spawner
  tiempoSpawnZombie++;
  if (tiempoSpawnZombie > 70) {
    zombies.push(new Zombie());
    tiempoSpawnZombie = 0;
  }

  // creacion de civiles
  tiempoSpawnCivil++;
  if (tiempoSpawnCivil > 200) {
    civiles.push(new Civil());
    tiempoSpawnCivil = 0;
  }

  // Zombies ganan
  for (let i = zombies.length - 1; i >= 0; i--) {
    zombies[i].actualizar();
    zombies[i].dibujar();

    if (zombies[i].x > width) estadoJuego = "derrota";
  }

  // Poder gracias a los civiles
  for (let i = civiles.length - 1; i >= 0; i--) {
    civiles[i].actualizar();
    civiles[i].dibujar();

    if (civiles[i].x > width) {
      civiles.splice(i, 1);
      jugador.activarPoder();
    }
  }

  //mas balas 
  for (let i = balas.length - 1; i >= 0; i--) {
    balas[i].actualizar();
    balas[i].dibujar();

    // vida de los zombies 
    for (let j = zombies.length - 1; j >= 0; j--) {
      if (dist(balas[i].x, balas[i].y, zombies[j].x, zombies[j].y) < 20) {

        zombies[j].hp -= balas[i].especial ? 2 : 1;
        balas.splice(i, 1);

        if (zombies[j].hp <= 0) {
          sonidoZombie.play(); // efecto de sonido de muerte de zombie
          zombies.splice(j, 1);
          zombiesEliminados++;
          
          //Cantidad de zombies muertos requeridos para ganar
          if (zombiesEliminados >= 20) estadoJuego = "victoria";
        }
        break;
      }
    }

    // Muerte de civiles
    for (let c = civiles.length - 1; c >= 0; c--) {
      if (dist(balas[i]?.x, balas[i]?.y, civiles[c].x, civiles[c].y) < 14) {
        civiles.splice(c, 1);
        balas.splice(i, 1);
        break;
      }
    }

    if (balas[i] && balas[i].x < 0) balas.splice(i, 1);
  }

  // objetivo de zombies a eliminar
  fill(255);
  textSize(16);
  text(`Zombies eliminados: ${zombiesEliminados} / 20`, 140, 30);
}

// Felicidades ganaste
function dibujarVictoria() {
  fill(255);
  textAlign(CENTER);
  textSize(32);
  text("¡Salvaste a todos!", width / 2, 200);
  textSize(16);
  text("Presiona R para reiniciar", width / 2, 260);
}

// Maldita sea perdiste 
function dibujarDerrota() {
  fill(255);
  textAlign(CENTER);
  textSize(32);
  text("No pudiste salvarlos...", width / 2, 200);
  textSize(16);
  text("Presiona R para reiniciar", width / 2, 260);
}

// Cambio entre pantallas
function keyPressed() {
  if (key === " " && estadoJuego === "juego") jugador.disparar();

  if (estadoJuego === "menu" && keyCode === ENTER) {
    estadoJuego = "tutorial";
    tiempoTutorial = 240;
  }

  if ((estadoJuego === "victoria" || estadoJuego === "derrota") && key === "r") {
    reiniciarJuego();
  }
}
// Reiniciar todo
function reiniciarJuego() {
  estadoJuego = "menu";
  jugador = new Jugador();
  zombies = [];
  civiles = [];
  balas = [];
  zombiesEliminados = 0;
  tiempoSpawnZombie = 0;
  tiempoSpawnCivil = 0;
  tiempoPowerUp = 0;
}
